
		<style>
				table, th ,td{
					border:1px solid black;
				}
		</style>	
<div class="box-content">	
	<div class="row">
	 <div class="col-lg-20">
	  <p class="introtext"><?= lang('list_results'); ?></p>
	  <div class="table-responsive">
	<body>
		<table cellpadding="1" cellspacing="0">
			<thead>
				<tr>
					<th colspan="6"></th>
					<th colspan="14">2016</th>
				</tr>
			</thead>
			<thead>
				<tr>
					<th>Code</th>
					<th>Project</th>
					<th>Amount</th>
					<th>Period</th>
					<th>Start Date</th>
					<th>End Date</th>
					<th>Jan</th>
					<th>Feb</th>
					<th>Mar</th>
					<th>Apr</th>
					<th>May</th>
					<th>Jun</th>
					<th>Jul</th>
					<th>Aug</th>
					<th>Sep</th>
					<th>Oct</th>
					<th>Nov</th>
					<th>Dec</th>
					<th>Total</th>
					<th>Balance</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
					<td>$</td>
				</tr>
			</tbody>
			<tfoot>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td colspan="3"></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
			</tfoot>
		</table>
		</div>
		</div>
	</div>	
</div>		
	