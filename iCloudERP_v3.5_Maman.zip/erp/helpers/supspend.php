<?php defined('BASEPATH') OR exit('No direct script access allowed');


if(! function_exists('supspend')) {
    function supspend() {
		return 'hello hhh';
    }
}
