<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Module: Products
 * Language: English
 *
 * Last edited:
 * 30th April 2015
 *
 * Package:
 * iCloudERP ACC 3.0
 *
 * You can translate this file to your language.
 * For instruction on new language setup, please visit the documentations.
 * You also can share your language files by emailing to icloud.erp@gmail.com
 * Thank you
 */

$lang['add_product']                       		= "添加產品";
$lang['edit_user']                        		= "編輯用戶";
$lang['delete_employees']              		= "刪除員工";