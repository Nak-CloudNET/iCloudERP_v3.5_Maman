<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Module: Products
 * Language: English
 *
 * Last edited:
 * 30th April 2015
 *
 * Package:
 * iCloudERP ACC 3.0
 *
 * You can translate this file to your language.
 * For instruction on new language setup, please visit the documentations.
 * You also can share your language files by emailing to icloud.erp@gmail.com
 * Thank you
 */
$lang['reference']                        	= "參考";
$lang['add_marchine']						= "添加計算機";
$lang["delete_marchines"]				= "刪除機";
$lang["list_marchines"]					= "列表機";
 