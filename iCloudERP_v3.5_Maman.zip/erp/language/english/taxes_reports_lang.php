<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Language: English
 * Module: Suppliers
 * 
 * Last edited:
 * 30th April 2015
 *
 * Package:
 * iCloudERP - POS v3.0
 * 
 * You can translate this file to your language. 
 * For instruction on new language setup, please visit the documentations. 
 * You also can share your language files by emailing to icloud.erp@gmail.com 
 * Thank you 
 */
$lang['taxes']									= "Taxes";
$lang['enterprise']							= "Enterprise";

$lang["from_date"]							= "From Date	";
$lang["to_date"]								= "To Date	";
$lang["create_date"]						= "Create Date";
$lang["view_report"]						= " View Report";
$lang["delete_report"]						= " Delete Report";
$lang["create_employee_salary"]		= "Create Employee Salary";
 
 
 
 
 
 
 
 
 
 
 
 
 


