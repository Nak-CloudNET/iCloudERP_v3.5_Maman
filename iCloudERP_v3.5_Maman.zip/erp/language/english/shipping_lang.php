<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Language: English
 * Module: Shipping
 *
 * Last edited:
 * 02rd June 2017
 *
 * Package:
 * iCloudERP 3.4
 *
 * You can translate this file to your language.
 * For instruction on new language setup, please visit the documentations.
 * You also can share your language files by emailing to icloud.erp@gmail.com
 * Thank you
 */

