<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Language: English
 * Module: Suppliers
 * 
 * Last edited:
 * 30th April 2015
 *
 * Package:
 * iCloudERP - POS v3.0
 * 
 * You can translate this file to your language. 
 * For instruction on new language setup, please visit the documentations. 
 * You also can share your language files by emailing to icloud.erp@gmail.com 
 * Thank you 
 */
$lang['taxes']									= "အခွန်";
$lang['enterprise']							= "စီးပွားရေးလုပ်ငန်း";

$lang["from_date"]							= "နေ့စွဲကနေ	";
$lang["to_date"]								= "ယနေ့အထိ	";
$lang["create_date"]						= "နေ့စွဲ ဖန်တီး";
$lang["view_report"]						= " ကြည့်ရန်အစီရင်ခံစာ";
$lang["delete_report"]						= " အစီရင်ခံစာဖျက်ပစ်ပါ";