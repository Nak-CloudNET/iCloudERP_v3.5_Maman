<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Language: English
 * Module: Suppliers
 * 
 * Last edited:
 * 30th April 2015
 *
 * Package:
 * iCloudERP - POS v3.0
 * 
 * You can translate this file to your language. 
 * For instruction on new language setup, please visit the documentations. 
 * You also can share your language files by emailing to icloud.erp@gmail.com 
 * Thank you 
 */

//documents
$lang["add_chart_account_csv"]			= "ဇယားအကောင့် CSV ကို Add";
$lang["add_chart_account"]				= "ဇယားအကောင့် Add";
$lang["delete_chart_accounts"]			= "ဇယား Accounts ကိုဖျက်ပစ်ပါ";
$lang["delete_account"]					= "အကောင့်ကိုဖျက်ပစ်ရန်";
$lang["edit_account"]					= "Edit ကိုအကောင့်ကို";
$lang["debit_amount"]					= "debit ပမာဏ";
$lang["credit_amount"]					= "အကြွေးပမာဏ";
$lang["account_code"]					= "အကောင့် Code";
$lang["account_name"]					= "အကောင့်နာမည်";
$lang["parent_account"]					= "မိဘအကောင့်";
$lang["account_section"]				= "အကောင့်ပုဒ်မ";