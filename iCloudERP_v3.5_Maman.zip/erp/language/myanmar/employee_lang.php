<?php defined('BASEPATH') OR exit('No direct script access allowed');

/*
 * Module: Products
 * Language: English
 *
 * Last edited:
 * 30th April 2015
 *
 * Package:
 * iCloudERP ACC 3.0
 *
 * You can translate this file to your language.
 * For instruction on new language setup, please visit the documentations. 
 * Thank you
 */

$lang['add_product']                       		= "ကုန်ပစ္စည်း Add";
$lang['edit_user']                        		= "Edit ကိုအသုံးပြုသူတို့";
$lang['delete_employees']              			= "ဝန်ထမ်းများဖျက်ပစ်ပါ";